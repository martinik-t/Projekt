package com.example.projekt

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp // Import pro fontSize
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BoxStatusApp()
        }
    }
}

// 🔹 Datová třída pro držení stavů
data class BoxStatus(
    val servoState: String = "Neznámý",
    val stavKrabice: String = "Neznámý"
)



@Composable
fun BoxStatusApp() {
    var boxStatus by remember { mutableStateOf(BoxStatus("Načítání...", "Načítání...")) }

    LaunchedEffect(Unit) {
        boxStatus = fetchBoxStatus()
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = MaterialTheme.colorScheme.primary,
            surface = MaterialTheme.colorScheme.surface,
            background = MaterialTheme.colorScheme.background
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFB0B0B0), // Tmavší šedá
                            Color(0xFFE0E0E0), // Světlejší šedá
                            Color(0xFFFFFFFF)  // Bílá
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "📦 Stav boxu",
                    style = MaterialTheme.typography.headlineLarge,
                    modifier = Modifier
                        .padding(bottom = 32.dp)
                )

                // 🔹 Stav serva karta s moderním vzhledem pro "Zavřeno" nebo "Otevřeno"
                Box(
                    modifier = Modifier
                        .background(
                            color = if (boxStatus.servoState.lowercase() == "open") Color(0xFF4CAF50) // Zelená pro Otevřeno
                            else Color(0xFFF44336), // Červená pro Zavřeno
                            shape = RoundedCornerShape(16.dp) // Zaoblené rohy pro moderní vzhled
                        )
                        .padding(horizontal = 40.dp, vertical = 16.dp) // Zvětšený padding
                ) {
                    Text(
                        text = if (boxStatus.servoState.lowercase() == "open") "Otevřeno" else "Zavřeno",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyLarge.copy(fontSize = 20.sp) // Zvětšení textu
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 🔹 Stav krabice karta bez nadpisu "Stav Schránky"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally // Zarovnání textu na střed
                    ) {
                        // Zmenšení textu pro "Schránka je prázdná"
                        Text(
                            text = if (boxStatus.stavKrabice.lowercase() == "plna") "Schránka je plná" else "Schránka je prázdná",
                            style = MaterialTheme.typography.bodyLarge.copy(fontSize = 20.sp), // Zmenšení textu pro "Schránka je prázdná"
                            textAlign = TextAlign.Center // Zarovnání na střed
                        )
                    }
                }
            }
        }
    }
}



suspend fun fetchBoxStatus(): BoxStatus = withContext(Dispatchers.IO) {
    try {
        val apiKey = "AIzaSyC1oK9T1jjmNsRnKnPvbci6idWWGVC4XFs"

        // Načítání z větve "security" pro servoState
        val securityUrl = "https://test-1e784-default-rtdb.europe-west1.firebasedatabase.app/security.json?auth=$apiKey"
        val securityRequest = Request.Builder().url(securityUrl).build()
        val securityResponse = OkHttpClient().newCall(securityRequest).execute()
        val securityBody = securityResponse.body?.string()

        // Načítání z větve "stav_krabice" pro stavKrabice
        val stavKrabiceUrl = "https://test-1e784-default-rtdb.europe-west1.firebasedatabase.app/stav_krabice.json?auth=$apiKey"
        val stavKrabiceRequest = Request.Builder().url(stavKrabiceUrl).build()
        val stavKrabiceResponse = OkHttpClient().newCall(stavKrabiceRequest).execute()
        val stavKrabiceBody = stavKrabiceResponse.body?.string()

        // 🔍 Výpis JSON odpovědi z Firebase do Logcat
        println("🔥 Security response: $securityBody")
        println("🔥 StavKrabice response: $stavKrabiceBody")

        val servoState = if (!securityBody.isNullOrEmpty()) {
            try {
                val securityJson = JSONObject(securityBody)
                securityJson.optString("servoState", "Neznámý")
            } catch (e: Exception) {
                println("❌ Chyba při zpracování security odpovědi: ${e.message}")
                "Neznámý"
            }
        } else {
            println("❌ Odpověď z Firebase pro security je prázdná nebo neexistuje.")
            "Neznámý"
        }

        val stavKrabice = if (!stavKrabiceBody.isNullOrEmpty()) {
            stavKrabiceBody.trim('"') // odstraní uvozovky ze stringu
        } else {
            println("❌ Odpověď z Firebase pro stavKrabice je prázdná.")
            "Neznámý"
        }

        return@withContext BoxStatus(servoState, stavKrabice)

    } catch (e: Exception) {
        println("❌ Chyba při načítání: ${e.message}")
        return@withContext BoxStatus("Chyba", "Chyba")
    }
}
